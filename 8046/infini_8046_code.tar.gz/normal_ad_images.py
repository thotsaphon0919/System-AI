from __future__ import annotations

import json
import secrets
from pathlib import Path
from typing import Any

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.responses import FileResponse, HTMLResponse, RedirectResponse, Response
from starlette.middleware.base import BaseHTTPMiddleware


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"
UPLOAD_DIR = BASE_DIR / "uploads" / "normal_ad_media"
INDEX_FILE = DATA_DIR / "normal_ad_media.json"

DATA_DIR.mkdir(parents=True, exist_ok=True)
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)

IMAGE_EXTENSIONS = {".jpg", ".jpeg", ".png", ".webp", ".gif"}
VIDEO_EXTENSIONS = {".mp4", ".webm", ".mov", ".m4v"}
ALLOWED_EXTENSIONS = IMAGE_EXTENSIONS | VIDEO_EXTENSIONS
MAX_IMAGE_SIZE = 12 * 1024 * 1024
MAX_VIDEO_SIZE = 250 * 1024 * 1024
REWARD_ORDER = ["watch", "shoe", "gift", "bag"]


def _load_index() -> dict[str, Any]:
    if not INDEX_FILE.exists():
        return {"ads": {}}
    try:
        data = json.loads(INDEX_FILE.read_text("utf-8"))
        return data if isinstance(data.get("rewards"), dict) else {"ads": {}}
    except (OSError, json.JSONDecodeError, AttributeError):
        return {"ads": {}}


def _save_index(data: dict[str, Any]) -> None:
    temp = INDEX_FILE.with_suffix(".tmp")
    temp.write_text(json.dumps(data, ensure_ascii=False, indent=2), "utf-8")
    temp.replace(INDEX_FILE)


def _clean_ad_id(value: str) -> str:
    cleaned = "".join(
        ch for ch in value.strip().lower()
        if ch in "abcdefghijklmnopqrstuvwxyz0123456789-_"
    )
    if not cleaned:
        raise HTTPException(status_code=400, detail="รหัสโฆษณาไม่ถูกต้อง")
    return cleaned[:80]


def _kind(info: dict[str, Any]) -> str:
    if info.get("kind") in {"image", "video"}:
        return str(info["kind"])
    suffix = Path(str(info.get("stored_name", ""))).suffix.lower()
    return "video" if suffix in VIDEO_EXTENSIONS else "image"


def _media_block(ad_id: str, detail: bool = False) -> str:
    safe_id = _clean_ad_id(ad_id)
    info = _load_index()["ads"].get(safe_id)

    if info and _kind(info) == "video":
        options = "controls" if detail else "autoplay muted loop"
        media = (
            f'<video src="/normal-ad-media/{safe_id}" '
            f'playsinline preload="metadata" {options} '
            'style="width:100%;height:100%;object-fit:cover;'
            'display:block;background:#000"></video>'
        )
    elif info:
        media = (
            f'<img src="/normal-ad-media/{safe_id}" '
            f'alt="สื่อโฆษณา {safe_id}" loading="lazy" '
            'style="width:100%;height:100%;object-fit:cover;'
            'display:block;background:#050816">'
        )
    else:
        media = (
            '<div style="width:100%;height:100%;display:flex;'
            'align-items:center;justify-content:center;text-align:center;'
            'padding:22px;color:#c4b5fd;font-size:20px;line-height:1.5;'
            'background:linear-gradient(145deg,#25105b,#050816)">'
            'กดเพื่ออัปโหลด<br>รูปหรือวิดีโอ</div>'
        )

    return (
        f'<a href="/normal-ad-upload/{safe_id}" '
        'style="position:relative;display:block;width:100%;'
        'aspect-ratio:2/3;overflow:hidden;border-radius:20px;'
        'text-decoration:none;background:#050816">'
        f'{media}'
        '<span style="position:absolute;right:10px;bottom:10px;'
        'padding:8px 11px;border-radius:999px;color:#fff;font-size:13px;'
        'font-weight:700;background:rgba(2,6,23,.78);'
        'border:1px solid rgba(167,139,250,.8)"></span>'
        '</a>'
    )


class NormalRewardMediaMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
        response = await call_next(request)
        path = request.url.path
        is_list = path == "/tower/rewards"
        is_detail = path.startswith("/tower/redeem/")

        if not is_list and not is_detail:
            return response
        if "text/html" not in response.headers.get("content-type", ""):
            return response

        body = b""
        async for chunk in response.body_iterator:
            body += chunk
        html = body.decode("utf-8", errors="replace")

        if is_list:
            for ad_id in REWARD_ORDER:
                html = html.replace("รูปของโฆษณา", _media_block(ad_id), 1)
        else:
            ad_id = path.rsplit("/", 1)[-1]
            html = html.replace(
                "รูปและรายละเอียดของโฆษณา",
                _media_block(ad_id, detail=True),
                1,
            )

        headers = dict(response.headers)
        headers.pop("content-length", None)
        return Response(
            content=html,
            status_code=response.status_code,
            headers=headers,
            media_type="text/html",
        )


def setup_normal_ad_images(app: FastAPI) -> None:
    app.add_middleware(NormalRewardMediaMiddleware)

    @app.get("/normal-ad-upload/{ad_id}", response_class=HTMLResponse)
    async def upload_page(ad_id: str, request: Request) -> HTMLResponse:
        safe_id = _clean_ad_id(ad_id)
        back_url = request.headers.get("referer") or "/tower/rewards"
        preview = _media_block(safe_id, detail=True)

        return HTMLResponse(f'''<!doctype html>
<html lang="th">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>อัปโหลดสื่อโฆษณา</title>
<style>
*{{box-sizing:border-box}}
body{{margin:0;background:linear-gradient(180deg,#16052f,#020617);color:#fff;font-family:system-ui,-apple-system,sans-serif}}
.wrap{{max-width:680px;margin:auto;padding:22px 16px 56px}}
.card{{background:#080d20;border:1px solid #7c3aed;border-radius:28px;overflow:hidden}}
.preview-wrap{{padding:18px}}
.pad{{padding:22px}}
h1{{margin:0 0 8px;color:#d8b4fe}}
p{{color:#aab6d0;line-height:1.6}}
input{{width:100%;padding:14px;border:1px solid #6d28d9;border-radius:14px;background:#020617;color:#fff}}
button,.back{{display:flex;align-items:center;justify-content:center;width:100%;padding:15px;margin-top:14px;border:0;border-radius:15px;background:#7c3aed;color:#fff;text-decoration:none;font-size:17px;font-weight:800}}
.back{{background:#172036;border:1px solid #4c5f85}}
.note{{color:#fcd34d;font-size:14px}}
</style>
</head>
<body>
<div class="wrap">
  <div class="card">
    <div class="preview-wrap">{preview}</div>
    <div class="pad">
      <h1>สื่อเต็มแผ่น 2:3</h1>
      <p>รหัสโฆษณา: <b>{safe_id}</b></p>
      <form method="post" action="/normal-ad-upload/{safe_id}" enctype="multipart/form-data">
        <input type="file" name="media" accept="image/*,video/mp4,video/webm,video/quicktime" required>
        <input type="hidden" name="back_url" value="{back_url}">
        <button type="submit">อัปโหลด / เปลี่ยนรูปหรือวิดีโอ</button>
      </form>
      <p class="note">รูปไม่เกิน 12 MB · วิดีโอไม่เกิน 250 MB</p>
      <a class="back" href="{back_url}">ย้อนกลับ</a>
    </div>
  </div>
</div>
</body>
</html>''')

    @app.post("/normal-ad-upload/{ad_id}")
    async def upload_media(
        ad_id: str,
        request: Request,
        media: UploadFile = File(...),
    ):
        safe_id = _clean_ad_id(ad_id)
        filename = media.filename or ""
        suffix = Path(filename).suffix.lower()

        if suffix not in ALLOWED_EXTENSIONS:
            raise HTTPException(status_code=400, detail="ชนิดไฟล์ไม่รองรับ")

        kind = "video" if suffix in VIDEO_EXTENSIONS else "image"
        max_size = MAX_VIDEO_SIZE if kind == "video" else MAX_IMAGE_SIZE
        content = await media.read(max_size + 1)
        await media.close()

        if len(content) > max_size:
            raise HTTPException(status_code=413, detail="ไฟล์ใหญ่เกินกำหนด")

        index = _load_index()
        old = index["ads"].get(safe_id)
        if old:
            old_path = UPLOAD_DIR / str(old.get("stored_name", ""))
            if old_path.is_file():
                old_path.unlink()

        stored_name = f"{safe_id}-{secrets.token_hex(6)}{suffix}"
        (UPLOAD_DIR / stored_name).write_bytes(content)
        index["ads"][safe_id] = {
            "stored_name": stored_name,
            "original_name": filename or stored_name,
            "content_type": media.content_type or (
                "video/mp4" if kind == "video" else "image/jpeg"
            ),
            "kind": kind,
            "size": len(content),
        }
        _save_index(index)

        form = await request.form()
        back_url = str(form.get("back_url") or f"/tower/ad/{safe_id}")
        return RedirectResponse(url=back_url, status_code=303)

    @app.get("/normal-ad-media/{ad_id}")
    async def serve_media(ad_id: str):
        safe_id = _clean_ad_id(ad_id)
        info = _load_index()["ads"].get(safe_id)
        if not info:
            raise HTTPException(status_code=404, detail="ยังไม่มีสื่อโฆษณา")

        path = UPLOAD_DIR / str(info.get("stored_name", ""))
        if not path.is_file():
            raise HTTPException(status_code=404, detail="ไม่พบไฟล์สื่อ")

        return FileResponse(
            path,
            media_type=info.get("content_type") or "application/octet-stream",
        )
